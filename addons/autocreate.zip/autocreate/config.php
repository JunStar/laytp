<?php
return [
    ['wx_app_key','input','微信app_key'],
    ['wx_secret','input','微信secret'],
];