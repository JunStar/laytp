<?php
return [
    [
        'name'=>'AccessKeyID'
        ,'tip'=>'阿里云密钥管理中设置的AccessKeyID'
        ,'key'=>'access_key_id'
        ,'type'=>'input'
        ,'content'=>''
    ],
    [
        'name'=>'AccessKeySecret'
        ,'tip'=>'阿里云密钥管理中设置的AccessKeySecret'
        ,'key'=>'access_key_secret'
        ,'type'=>'input'
        ,'content'=>''
    ]
];
