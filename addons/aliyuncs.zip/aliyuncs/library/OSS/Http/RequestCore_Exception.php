<?php

namespace addons\aliyuncs\library\OSS\Http;

class RequestCore_Exception extends \Exception
{

}