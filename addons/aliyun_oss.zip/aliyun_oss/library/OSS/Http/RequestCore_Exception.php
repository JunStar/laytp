<?php

namespace addons\aliyun_oss\library\OSS\Http;

class RequestCore_Exception extends \Exception
{

}